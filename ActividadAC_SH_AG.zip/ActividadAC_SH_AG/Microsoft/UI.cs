﻿namespace Microsoft
{
    internal class UI
    {
    }
}