﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ActividadAC_SH_AG
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerlin_Click(object sender, RoutedEventArgs e)
        {
            // Deshabilitar los demás botones
            btnRoma.IsEnabled = false;
            btnParis.IsEnabled = false;
            btnLondres.IsEnabled = false;
            txtPerdido.Visibility = Visibility.Visible;
            btnTerminar.Visibility = Visibility.Visible;
            btnBerlin.Background = Brushes.Red;
        }
        private void BtnLondres_Click(object sender, RoutedEventArgs e)
        {
            // Deshabilitar los demás botones
            btnRoma.IsEnabled = false;
            btnParis.IsEnabled = false;
            btnBerlin.IsEnabled = false;
            txtPerdido.Visibility = Visibility.Visible;
            btnTerminar.Visibility = Visibility.Visible;
            btnLondres.Background = Brushes.Red;
        }
        private void BtnParis_Click(object sender, RoutedEventArgs e)
        {
            // Deshabilitar los demás botones
            btnRoma.IsEnabled = false;
            btnBerlin.IsEnabled = false;
            btnLondres.IsEnabled = false;
            btnSiguiente.Visibility = Visibility.Visible;
            btnParis.Background = Brushes.Green;
        }
        private void BtnRoma_Click(object sender, RoutedEventArgs e)
        {
            // Deshabilitar los demás botones
            btnParis.IsEnabled = false;
            btnBerlin.IsEnabled = false;
            btnLondres.IsEnabled = false;
            txtPerdido.Visibility = Visibility.Visible;
            btnTerminar.Visibility = Visibility.Visible;
            btnRoma.Background = Brushes.Red;
        }

        private void BtnEmpezarJuego_Click(object sender, EventArgs e)
        {
            List<Participante> participantes = new List<Participante>();

            // Crear un nuevo Participante con el nombre del TextBoxNombre
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            Participante nuevoParticipante = new Participante(nombre, apellido);

            // Verificar si los campos de nombre y apellido están vacíos
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellido))
            {
                // Mostrar un mensaje de error al usuario
                MessageBox.Show("Debe ingresar su nombre y apellido antes de continuar.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                // Agregar el nuevo participante a la lista de participantes
                participantes.Add(nuevoParticipante);

                // Ocultar la primera pestaña y mostrar la segunda
                tabControl.SelectedIndex = 1;
            }
        }
    }
}
