﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ActividadAC_SH_AG
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Participante participanteActual;
        List<Participante> participantes = new List<Participante>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnParis_Click(object sender, RoutedEventArgs e)
        {
            participanteActual.Puntuacion += 20;
            // Deshabilitar los demás botones
            btnRoma.IsEnabled = false;
            btnBerlin.IsEnabled = false;
            btnLondres.IsEnabled = false;
            btnSiguiente.Visibility = Visibility.Visible;
            btnParis.Background = Brushes.Green;
        }
        private void BtnRoma_Click(object sender, RoutedEventArgs e)
        {
            txtpuntuacionuno.Text = "Puntuación final: " + participanteActual.Puntuacion;
            // Deshabilitar los demás botones
            btnParis.IsEnabled = false;
            btnBerlin.IsEnabled = false;
            btnLondres.IsEnabled = false;
            txtpuntuacionuno.Visibility = Visibility.Visible;
            txtPerdido.Visibility = Visibility.Visible;
            btnTerminar.Visibility = Visibility.Visible;
            btnRoma.Background = Brushes.Red;
            participantes.Add(participanteActual);
        }
        private void BtnBerlin_Click(object sender, RoutedEventArgs e)
        {
            txtpuntuacionuno.Text = "Puntuación final: " + participanteActual.Puntuacion;
            // Deshabilitar los demás botones
            btnRoma.IsEnabled = false;
            btnParis.IsEnabled = false;
            btnLondres.IsEnabled = false;
            txtpuntuacionuno.Visibility = Visibility.Visible;
            txtPerdido.Visibility = Visibility.Visible;
            btnTerminar.Visibility = Visibility.Visible;
            btnBerlin.Background = Brushes.Red;
            participantes.Add(participanteActual);
        }
        private void BtnLondres_Click(object sender, RoutedEventArgs e)
        {
            txtpuntuacionuno.Text = "Puntuación final: " + participanteActual.Puntuacion;
            // Deshabilitar los demás botones
            btnRoma.IsEnabled = false;
            btnParis.IsEnabled = false;
            btnBerlin.IsEnabled = false;
            txtpuntuacionuno.Visibility = Visibility.Visible;
            txtPerdido.Visibility = Visibility.Visible;
            btnTerminar.Visibility = Visibility.Visible;
            btnLondres.Background = Brushes.Red;
            participantes.Add(participanteActual);
        }
        private void BtnCorrecta_Click(object sender, RoutedEventArgs e)
        {
            participanteActual.Puntuacion += 20;
            btnFalsauno.IsEnabled = false;
            btnFalsados.IsEnabled = false;
            btnFalsatres.IsEnabled = false;
            btnSiguientedos.Visibility = Visibility.Visible;
            btncorrecta.Background = Brushes.Green;
        }
        private void BtnFalsaUno_Click(object sender, RoutedEventArgs e)
        {
            txtpuntuaciondos.Text = "Puntuación final: " + participanteActual.Puntuacion;
            btncorrecta.IsEnabled = false;
            btnFalsados.IsEnabled = false;
            btnFalsatres.IsEnabled = false;
            txtpuntuaciondos.Visibility = Visibility.Visible;
            txtPerdidodos.Visibility = Visibility.Visible;
            btnTerminardos.Visibility = Visibility.Visible;
            btnFalsauno.Background = Brushes.Red;
            participantes.Add(participanteActual);
        }
        private void BtnFalsaDos_Click(object sender, RoutedEventArgs e)
        {
            txtpuntuaciondos.Text = "Puntuación final: " + participanteActual.Puntuacion;
            btncorrecta.IsEnabled = false;
            btnFalsauno.IsEnabled = false;
            btnFalsatres.IsEnabled = false;
            txtpuntuaciondos.Visibility = Visibility.Visible;
            txtPerdidodos.Visibility = Visibility.Visible;
            btnTerminardos.Visibility = Visibility.Visible;
            btnFalsados.Background = Brushes.Red;
            participantes.Add(participanteActual);
        }
        private void BtnFalsaTres_Click(object sender, RoutedEventArgs e)
        {
            txtpuntuaciondos.Text = "Puntuación final: " + participanteActual.Puntuacion;
            btncorrecta.IsEnabled = false;
            btnFalsados.IsEnabled = false;
            btnFalsauno.IsEnabled = false;
            txtpuntuaciondos.Visibility = Visibility.Visible;
            txtPerdidodos.Visibility = Visibility.Visible;
            btnTerminardos.Visibility = Visibility.Visible;
            btnFalsatres.Background = Brushes.Red;
            participantes.Add(participanteActual);
        }
        //-----------------------------------------------------------------------------------//
        private void BtnSiguiente_Click(object sender, RoutedEventArgs e)
        {
            tabControl.SelectedIndex = 2;
        }
        private void BtnSiguientedos_Click(object sender, RoutedEventArgs e)
        {
            tabControl.SelectedIndex = 3;
        }
        private void BtnInicio_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
        private void BtnTerminardos_Click(Object sender, RoutedEventArgs e)
        {
            Reset();
        }
        private void BtnTerminar_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
        private void Reset()
        {
            // Resetear los botones de las ciudades
            // Restaurar color original de los botones
            btnParis.ClearValue(Button.BackgroundProperty);
            btnRoma.ClearValue(Button.BackgroundProperty);
            btnBerlin.ClearValue(Button.BackgroundProperty);
            btnLondres.ClearValue(Button.BackgroundProperty);
            btncorrecta.ClearValue(Button.BackgroundProperty);
            btnFalsauno.ClearValue(Button.BackgroundProperty);
            btnFalsados.ClearValue(Button.BackgroundProperty);
            btnFalsatres.ClearValue(Button.BackgroundProperty);

            // Habilitar los botones y ocultar las etiquetas de texto
            btnParis.IsEnabled = true;
            btnRoma.IsEnabled = true;
            btnBerlin.IsEnabled = true;
            btnLondres.IsEnabled = true;
            btncorrecta.IsEnabled = true;
            btnFalsauno.IsEnabled = true;
            btnFalsados.IsEnabled = true;
            btnFalsatres.IsEnabled = true;

            // Resetear las etiquetas de pérdida
            txtPerdido.Visibility = Visibility.Collapsed;
            txtPerdidodos.Visibility = Visibility.Collapsed;
            txtpuntuacionuno.Visibility = Visibility.Collapsed;
            txtpuntuaciondos.Visibility = Visibility.Collapsed;

            // Resetear los botones de navegación
            btnSiguiente.Visibility = Visibility.Collapsed;
            btnSiguientedos.Visibility = Visibility.Collapsed;
            btnTerminar.Visibility = Visibility.Collapsed;
            btnTerminardos.Visibility = Visibility.Collapsed;

            // Resetear el estado de las pestañas
            tabControl.SelectedIndex = 0;

            // Limpiar los campos de nombre y apellido
            txtNombre.Text = "";
            txtApellido.Text = "";
        }

        //------------------------------------------------------------------------------------//
        private void BtnEmpezarJuego_Click(object sender, EventArgs e)
        {
            // Crear un nuevo Participante con el nombre del TextBoxNombre
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            Participante nuevoParticipante = new Participante(nombre, apellido, 0);

            participanteActual = nuevoParticipante;

            // Verificar si los campos de nombre y apellido están vacíos
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellido))
            {
                // Mostrar un mensaje de error al usuario
                MessageBox.Show("Debe ingresar su nombre y apellido antes de continuar.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                participantes.Add(nuevoParticipante);
                // Ocultar la primera pestaña y mostrar la segunda
                tabControl.SelectedIndex = 1;
            }
        }


    }
}
