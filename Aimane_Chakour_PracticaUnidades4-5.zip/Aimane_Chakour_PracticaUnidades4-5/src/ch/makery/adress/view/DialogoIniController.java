package ch.makery.adress.view;


import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
/**

La clase DialogoIniController representa el controlador asociado al di�logo de inicio de sesi�n de la aplicaci�n.
@author Aimane Chakour
@version 1.0

*/
public class DialogoIniController {

    @FXML
    private ResourceBundle resources;
    
    /**
     * Componente PasswordField para introducir la contrase�a.
     */
    @FXML
    private PasswordField contraField;
    
    /**
     * Componente TextField para introducir el usuario.
     */
    @FXML
    private TextField usuarioField;

    /**
     * Propiedad que almacena el objeto Stage correspondiente a este di�logo.
     */
    private Stage dialogStage;
    
    /**
     * Controlador del men� principal de la aplicaci�n.
     */
    private MenuController menuc;
    
    /**
     * M�todo autom�ticamente llamado al inicializar la vista.
     */
    @FXML
    void initialize() {
        assert contraField != null : "fx:id=\"contraField\" was not injected: check your FXML file 'DialogoInicio.fxml'.";
        assert usuarioField != null : "fx:id=\"usuarioField\" was not injected: check your FXML file 'DialogoInicio.fxml'.";

    }
    
    /**
     * M�todo set para establecer el controlador del men� principal de la aplicaci�n.
     * 
     * @param menuc controlador del men� principal de la aplicaci�n
     */
    public void setMenuController(MenuController menuc) {
    	this.menuc = menuc;
    }
    
    /**
     * M�todo invocado al pulsar el bot�n de acceso.
     * 
     * @param event evento de pulsaci�n del bot�n
     */
    @FXML
    void AccesoForm(ActionEvent event) {
    	
    	if(usuarioField.getText().equals("admin") && contraField.getText().equals("12345")) {
    	this.menuc.abrirFormulario();
    	this.dialogStage.close();
    	}
    	else {
        	// Se muestra un alert si no se puede eliminar la fila
    		Alert errorAlert = new Alert(AlertType.ERROR);
        	
    		errorAlert.setTitle("ERROR DE ACCESO");
    		errorAlert.setHeaderText("Usuario o contrase�a incorrectos");
    		errorAlert.setContentText("Por favor, introduzca correctamente los datos");
    		
    		errorAlert.showAndWait();
    	}
    }
    /**
     * M�todo invocado al pulsar el bot�n de registro.
     * 
     * @param event evento de pulsaci�n del bot�n
     */
    @FXML
    void AccesoRegistro(ActionEvent event) {

    }
    /**
     * M�todo set de la propiedad dialogStage
     * 
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }



}

