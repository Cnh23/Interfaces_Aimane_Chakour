package ch.makery.adress.view;

import java.io.IOException;


import java.net.URL;
import java.util.ResourceBundle;

import ch.makery.adress.model.Persona;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ChoiceBox;

/**

Clase que representa el controlador de la interfaz gr�fica del formulario.
Se encarga de gestionar las acciones de los componentes de la interfaz y de mantener la informaci�n de las personas registradas en la aplicaci�n.
@author Aimane Chakour

@version 1.0
*/
public class FormController {
	/**
	 * Referencia al recurso de los recursos internos de la aplicaci�n.
	 */
	@FXML
	private ResourceBundle resources;

	/**
	 * Referencia a la ubicaci�n del archivo FXML que representa la interfaz gr�fica.
	 */
	@FXML
	private URL location;

	/**
	 * Referencia al componente TextField que permite ingresar los apellidos de una persona.
	 */
	@FXML
	private TextField ApellidosField;

	/**
	 * Referencia al componente TextField que permite ingresar el correo electr�nico de una persona.
	 */
	@FXML
	private TextField correoField;

	/**
	 * Referencia al componente TextField que permite ingresar el c�digo postal de una persona.
	 */
	@FXML
	private TextField cpField;

	/**
	 * Referencia al componente TextField que permite ingresar la direcci�n de una persona.
	 */
	@FXML
	private TextField direccionField;

	/**
	 * Referencia al componente TableColumn que muestra el DNI de las personas registradas en la aplicaci�n.
	 */
	@FXML
	private TableColumn<Persona, String> dniCol;

	/**
	 * Referencia al componente ChoiceBox que permite seleccionar la p�liza que desea contratar una persona.
	 */
	@FXML
	private ChoiceBox<String> poliChoice;

	/**
	 * Referencia al componente ChoiceBox que permite seleccionar la frecuencia de pago de la prima que desea contratar una persona.
	 */
	@FXML
	private ChoiceBox<String> primaChoice;

	/**
	 * Referencia al componente ChoiceBox que permite seleccionar el tipo de cobertura que desea contratar una persona.
	 */
	@FXML
	private ChoiceBox<String> coberturaChoice;

	/**
	 * Referencia al componente TextField que permite ingresar el DNI de una persona.
	 */
	@FXML
	private TextField dniField;

	/**
	 * Referencia al componente TextField que permite ingresar la fecha de nacimiento de una persona.
	 */
	@FXML
	private TextField fechanacField;
	/**
	 * Referencia al componente TextField que permite ingresar el nombre de una persona.
	 */
    @FXML
    private TextField nombreField;
    /**
     * Referencia al componente TableColumn que permite visualizar nombre y apellido en una tabla.
     */
    @FXML
    private TableColumn<Persona, String> nyaCol;
    /**
     * Referencia al componente TableColumn que permite visualizar nombre y apellido en una tabla.
     */
    @FXML
    private TableColumn<Persona, String> apeCol;
    /**
     * Referencia al componente TableView que permite visualizar los datos en una tabla.
     */
    @FXML
    private TableView<Persona> tablaPersonas;

    /**
	 * Campo de texto para introducir el n�mero de tel�fono.
	 */
	@FXML
	private TextField telField;
	
	/**
	 * Bot�n de selecci�n para aceptar los t�rminos y condiciones.
	 */
	@FXML
	private RadioButton termsRB;
    
    
    
	/**
	 * Lista observable de personas en la aplicaci�n.
	 */
	private static ObservableList<Persona> personaData = FXCollections.observableArrayList();
	
	
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama al inicializar la vista.
	 * Inicializa las opciones en los desplegables y carga datos de prueba en la tabla de personas.
	 * @param event evento de pulsaci�n del bot�n
	 */
    @FXML
    void initialize() {
    	
    	coberturaChoice.getItems().addAll("B�sica","Limitada","Amplia","Amplia Plus");
    	coberturaChoice.setValue("Seleccione cobertura...");
    	poliChoice.getItems().addAll("Coche","Moto","Hogar","Vida", "Salud", "Responsabilidad civil");
    	poliChoice.setValue("Seleccione p�liza...");
    	primaChoice.getItems().addAll("Trimestrales","Semestrales","Anuales");
    	primaChoice.setValue("Seleccione prima...");
		if(personaData.isEmpty()) {
			personaData.add(new Persona("ClienteUno","Uno", "12345678A", "Coche", "Trimestrales", "Amplia", "Clienteuno@cliente.com", Utilidades.parse("12/12/2000"), 28001, "Madrid", 666666661));
			personaData.add(new Persona("ClienteDos","Dos", "12345678B", "Salud", "Semestrales", "Limitada", "Clientedos@cliente.com", Utilidades.parse("12/12/2001"), 28002, "Madrid", 666666662));
			personaData.add(new Persona("ClienteTres","Tres",  "12345678D", "Coche", "Trimestrales", "B�sica", "Clientetres@cliente.com", Utilidades.parse("12/12/2002"), 28003,"Barcelona", 666666663));
			personaData.add(new Persona("ClienteCuatro","Cuatro", "12345678E", "Vida", "Semestrales", "Amplia", "Clientecuatro@cliente.com", Utilidades.parse("12/12/2003"), 28004,"Barcelona", 666666664));
			personaData.add(new Persona("ClienteCinco","Cinco", "12345678F", "Salud", "Trimestrales", "Limitada", "Clientecinco@cliente.com", Utilidades.parse("12/12/2004"), 28005,"Madrid", 666666665));
			personaData.add(new Persona("ClienteSeis","Seis", "12345678G", "Coche", "Anuales", "B�sica", "Clienteseis@cliente.com", Utilidades.parse("12/12/2005"), 28006,"Madrid", 666666666));
		}
		  tablaPersonas.setItems(personaData);
    	
    	
    	// Se inicializan las columnas firstName y lastName
    	nyaCol.setCellValueFactory(cellData -> cellData.getValue().sNombreProperty());
    	apeCol.setCellValueFactory(cellData -> cellData.getValue().sApellidosProperty());
    	dniCol.setCellValueFactory(cellData -> cellData.getValue().sDniProperty());
    	
    	
    }
    
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama al hacer click en el bot�n insertar.
	 * Inserta los datos escritos por el cliente en una lista de Personas.
	 * @param event evento de pulsaci�n del bot�n
	 */
    @FXML
    private void InsertarClick(ActionEvent event) {
        if (isInputValid()) {
        	
            Persona pers = new Persona(null, null, null, null, null, null, null, null, 0, null, 0);
            
            pers.setSNombre(nombreField.getText());
            pers.setSApellidos(ApellidosField.getText());
            pers.setSDni(dniField.getText());
            pers.setSCorreo(correoField.getText());
            pers.setSfechanac(Utilidades.parse(fechanacField.getText()));
            pers.setIcPostal(Integer.parseInt(cpField.getText()));
            pers.setSdireccion(direccionField.getText());
            pers.setItelefono(Integer.parseInt(telField.getText()));
            pers.setSCobertura(coberturaChoice.getValue());
            pers.setSPrima(poliChoice.getValue());
            pers.setSPoliza(primaChoice.getValue());
            
	        // Carga la persona en el controlador
            
            if(!personaData.contains(pers)) {
            getPersonData().add(pers);
            tablaPersonas.setItems(getPersonData());
            }
            restablecerFrom();
        }
   }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama al hacer click en el bot�n vaciar.
	 * Pone todos los par�metros en nulo.
	 * @param event evento de pulsaci�n del bot�n
	 */
    @FXML
    void vaciarForm(ActionEvent event) {
		// Si se ha seleccionado una fila, se muestra un pop up de confirmaci�n
		Alert confirm = new Alert(AlertType.CONFIRMATION);
    	
		confirm.setTitle("Confirmaci�n para limpiar formulario");
		//errorAlert.setHeaderText("Va a eliminar la fila seleccionada");
		confirm.setContentText("�Est� seguro de que desea vaciar el formulario?");
		    	    		
		// Si el usuario acepta, entonces se lleva a cabo la acci�n correspondiente
		confirm.showAndWait().ifPresent(response -> {
			if (response == ButtonType.OK) {
				restablecerFrom();
		    }
    });
		}
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama al hacer click en alg�n cliente de la tabla.
	 * Rellena todos los campos con los datos de ese cliente.
	 * @param event evento de pulsaci�n del bot�n
	 */
    @FXML
    void seleccionar(MouseEvent event) {
    	Persona selecpersona = this.tablaPersonas.getSelectionModel().getSelectedItem();
    	if(selecpersona!=null) {
        	nombreField.setText(selecpersona.getSNombre());
        	ApellidosField.setText(selecpersona.getSApellidos());
        	dniField.setText(selecpersona.getSDni());
        	correoField.setText(selecpersona.getSCorreo());
        	fechanacField.setText(Utilidades.format(selecpersona.getSfechanac()));
        	cpField.setText(Integer.toString(selecpersona.getIcPostal()));
        	direccionField.setText(selecpersona.getSdireccion());
        	telField.setText(Integer.toString(selecpersona.getItelefono()));
        	coberturaChoice.setValue(selecpersona.getSCobertura());
        	poliChoice.setValue(selecpersona.getSPoliza());
        	primaChoice.setValue(selecpersona.getSPrima());
    	}
    	
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que vac�a el formulario.
	 */
    private void restablecerFrom() {
        nombreField.setText(null);
        ApellidosField.setText(null);
        dniField.setText(null);
        correoField.setText(null);
        fechanacField.setText(null);
        cpField.setText(null);
        direccionField.setText(null);
        telField.setText(null);
        termsRB.setSelected(false);
        coberturaChoice.setValue(null);
        primaChoice.setValue(null);
        poliChoice.setValue(null);
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Se llama cuando el usuario hace click en el bot�n "Delete"
     * @param event evento de pulsaci�n del bot�n
     */
    @FXML
    private void borrarPersona(ActionEvent event) {
       	int selectedIndex = tablaPersonas.getSelectionModel().getSelectedIndex();
    	
    	// Si no hay ning�n campo seleccionado, se muestra un alert
    	if (selectedIndex >= 0) {
    		// Si se ha seleccionado una fila, se muestra un pop up de confirmaci�n
    		Alert confirm = new Alert(AlertType.CONFIRMATION);
        	
    		confirm.setTitle("Confirmaci�n para eliminar");
    		//errorAlert.setHeaderText("Va a eliminar la fila seleccionada");
    		confirm.setContentText("�Est� seguro de que desea eliminar al cliente seleccionado?");
    		    	    		
    		// Si el usuario acepta, entonces se lleva a cabo la acci�n correspondiente
    		confirm.showAndWait().ifPresent(response -> {
    			if (response == ButtonType.OK) {
    				tablaPersonas.getItems().remove(selectedIndex);
    		    }
    		});
    	} else {
    		// Se muestra un alert si no se puede eliminar la fila
    		Alert errorAlert = new Alert(AlertType.ERROR);
        	
    		errorAlert.setTitle("Error al eliminar");
    		errorAlert.setHeaderText("Se ha producido un error");
    		errorAlert.setContentText("No se puede eliminar porque no ha seleccionado una fila o la tabla est� vac�a");
    		
    		errorAlert.showAndWait();
    	}    	
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama al hacer click en el bot�n modificar.
	 * Cambia los datos de una persona por los nuevos datos introducidos por el usuario.
	 * @param event evento de pulsaci�n del bot�n
	 */
    @FXML
    void ModificarDatos(ActionEvent event) {
    	Persona personaseleccionada = this.tablaPersonas.getSelectionModel().getSelectedItem();
    	
    	if (personaseleccionada == null) {
    		Alert alert = new Alert(Alert.AlertType. ERROR);
    		alert.setHeaderText(null);

    		alert.setTitle("Error");

    		alert.setContentText("Desbes seleccionar una persona");
    		alert. showAndWait();
    	}	else {
            if (isInputValid()) {
            	
                Persona pers2 = new Persona(null, null, null, null, null, null, null, null, 0, null, 0);
                pers2.setSNombre(nombreField.getText());
                pers2.setSApellidos(ApellidosField.getText());
                pers2.setSDni(dniField.getText());
                pers2.setSCorreo(correoField.getText());
                pers2.setSfechanac(Utilidades.parse(fechanacField.getText()));
                pers2.setIcPostal(Integer.parseInt(cpField.getText()));
                pers2.setSdireccion(direccionField.getText());
                pers2.setItelefono(Integer.parseInt(telField.getText()));
                pers2.setSCobertura(coberturaChoice.getValue());
                pers2.setSPrima(poliChoice.getValue());
                pers2.setSPoliza(primaChoice.getValue());
                
                if(!this.personaData.contains(pers2)) {
                	personaseleccionada.setSNombre(pers2.getSNombre());
                	personaseleccionada.setSApellidos(pers2.getSApellidos());
                	personaseleccionada.setSDni(pers2.getSDni());
                	personaseleccionada.setSCorreo(pers2.getSCorreo());
                	personaseleccionada.setSfechanac(pers2.getSfechanac());
                	personaseleccionada.setIcPostal(pers2.getIcPostal());
                	personaseleccionada.setSdireccion(pers2.getSdireccion());
                	personaseleccionada.setItelefono(pers2.getItelefono());
                	personaseleccionada.setSCobertura(pers2.getSCobertura());
                	personaseleccionada.setSPrima(pers2.getSPrima());
                	personaseleccionada.setSPoliza(pers2.getSPoliza());
                	this.tablaPersonas.refresh();
                }
                else {
                	Alert alert = new Alert (Alert.AlertType. ERROR);
                		alert.setHeaderText (null);
                		alert.setTitle("Error");

                		alert.setContentText("La persona existe");
                		alert.showAndWait();
                		
                }
                restablecerFrom();
            }
         }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama para comprobar la validez de los datos del formulario.
	 * @param event evento de pulsaci�n del bot�n
	 */
    private boolean isInputValid() {
        String errorMessage = "";

        if (nombreField.getText() == null || nombreField.getText().length() == 0) {
            errorMessage += "El campo Nombre est� vac�o\n"; 
        }
        if (ApellidosField.getText() == null || ApellidosField.getText().length() == 0) {
            errorMessage += "El campo Apellido est� vac�o\n"; 
        }
        if (dniField.getText() == null || dniField.getText().length() == 0) {
            errorMessage += "El campo DNI est� vac�o\n"; 
        }
        else {
        	if (!Utilidades.validarDni(dniField.getText())) {
        		errorMessage += "El campo DNI no es v�lido\n";
			}
        }

        if (correoField.getText() == null || correoField.getText().length() == 0) {
            errorMessage += "El campo Correo est� vac�o\n";     
        } else {
        	if(!Utilidades.validarCorreo(correoField.getText())) {
        		errorMessage += "El correo no sigue el patr�n correcto\n";
        	}
        }
        
        if (direccionField.getText() == null || direccionField.getText().length() == 0) {
            errorMessage += "El campo Direcci�n est� vac�o\n";     
        } 
        if(cpField.getText().length() != 5) {
        	errorMessage += "El c�digo postal es incorrecto\n";   
        }
        if(telField.getText().length() != 9) {
        	errorMessage += "El tel�fono es incorrecto\n";   
        }

        
        else {
            // Se intenta convertir el C�digo postal y el tlf en entero y si da un error se muestra un mensaje
            try {
                Integer.parseInt(cpField.getText());
                Integer.parseInt(telField.getText());
            } catch (NumberFormatException e) {
                errorMessage += "C�digo postal o Tel�fono no v�lido. Debe ser un n�mero entero\n"; 
            }
        }


        if (fechanacField.getText() == null || fechanacField.getText().length() == 0) {
            errorMessage += "El campo Fecha de Nacimiento est� vac�o\n";
        } else {
            if (!Utilidades.validDate(fechanacField.getText())) {
                errorMessage += "El campo fecha de nacimiento no es v�lido. Usa el formato dd/mm/yyyy\n";
            }
        }
        if(poliChoice.getValue() == null) {
        	errorMessage += "Seleccione una p�liza\n";   
        }
        if(primaChoice.getValue() == null) {
        	errorMessage += "Seleccione una prima\n";   
        }
        if(coberturaChoice.getValue() == null) {
        	errorMessage += "Seleccione una cobertura\n";   
        }
        if(termsRB.isSelected()==false){
        	errorMessage += "Debes aceptar los t�rminos y condiciones\n";
        }
        
        if (errorMessage.length() == 0) {
        	/**
        	 * @return devuelve verdadero y se sale de la validaci�n
        	 */
            return true;
        } else {
        	// Se muestra un alert si no se puede eliminar la fila
    		Alert errorAlert = new Alert(AlertType.ERROR);
        	
    		errorAlert.setTitle("Hay campos incorrectos");
    		errorAlert.setHeaderText("Por favor, rellena correctamente los campos");
    		errorAlert.setContentText(errorMessage);
    		
    		errorAlert.showAndWait();
        	/**
        	 * @return devuelve falso y lanza ventana de aviso de errores
        	 */
            return false;
        }

    }
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static ObservableList<Persona> getPersonData() {
    	/**
    	 * @return devuelve observablelist de Persona
    	 */
		return personaData;
	}

    /////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * M�todo que se llama al hacer click en el bot�n gr�ficos.
	 * Abre un di�logo con los gr�ficos.
	 * @param event evento de pulsaci�n del bot�n
	 */
    @FXML
    void AbrirGrafico(MouseEvent event) {
  	    try {
	        // Cargamos el dise�o del di�logo desde un XML
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(FormController.class.getResource("Grafico.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();

	        // Se crea un nuevo Stage para mostrar el di�logo
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Gr�ficos generales");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        
	        
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);
	        
	        GraficoController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	        // Muestra el di�logo y no contin�a el c�digo hasta que lo cierra el usuario
	        dialogStage.showAndWait();

	    } catch (IOException e) {
	        e.printStackTrace();
	    }
    
    }
    }
