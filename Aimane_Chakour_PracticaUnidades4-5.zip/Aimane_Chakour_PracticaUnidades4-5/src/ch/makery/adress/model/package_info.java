/**
 * Contiene el los modelos de la aplicaci�n
 */
package ch.makery.adress.model;

