package ch.makery.adress.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
/**

La clase {@code Persona} representa un objeto persona con atributos como nombre, apellidos, DNI, poliza, prima, cobertura, correo, fecha de nacimiento, c�digo postal, direcci�n y tel�fono.

@author Aimane Chakour

@version 1.0
*/
public class Persona {
	/**

	Nombre de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sNombre;
	/**

	Apellidos de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sApellidos;
	/**

	DNI de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sDni;
	/**

	Poliza de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sPoliza;
	/**

	Prima de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sPrima;
	/**

	Cobertura de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sCobertura;
	/**

	Correo de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sCorreo;
	/**

	Fecha de nacimiento de la persona, se almacena como una propiedad ObjectProperty de tipo LocalDate.
	*/
	private final ObjectProperty<LocalDate> sfechanac;
	/**

	C�digo postal de la persona, se almacena como una propiedad IntegerProperty.
	*/
	private final IntegerProperty icPostal;
	/**

	Direcci�n de la persona, se almacena como una propiedad StringProperty.
	*/
	private final StringProperty sdireccion;
	/**

	Tel�fono de la persona, se almacena como una propiedad IntegerProperty.
	*/
	private final IntegerProperty itelefono;
	/**

	Constructor de la clase {@code Persona}. Crea un objeto persona con los atributos especificados.
	@param Nombre Nombre de la persona.
	@param Apellidos Apellidos de la persona.
	@param Dni DNI de la persona.
	@param Poliza Poliza de la persona.
	@param Prima Prima de la persona.
	@param Cobertura Cobertura de la persona.
	@param Correo Correo de la persona.
	@param fechanac Fecha de nacimiento de la persona.
	@param cPostal C�digo postal de la persona.
	@param direccion Fecha de nacimiento de la persona.
	@param itelefono C�digo postal de la persona.
	*/
	public Persona(String Nombre, String Apellidos, String Dni, String Poliza, String Prima, String Cobertura, String Correo, LocalDate fechanac, int cPostal, String direccion, int telefono) {

    	this.sNombre = new SimpleStringProperty(Nombre);
    	this.sApellidos = new SimpleStringProperty(Apellidos);
    	this.sDni = new SimpleStringProperty(Dni);
        this.sPoliza = new SimpleStringProperty(Poliza);
        this.sPrima = new SimpleStringProperty(Prima);
        this.sCobertura = new SimpleStringProperty(Cobertura);
        this.sCorreo = new SimpleStringProperty(Correo);
        this.sfechanac = new SimpleObjectProperty<LocalDate>(fechanac);
        this.icPostal = new SimpleIntegerProperty(cPostal);
        this.sdireccion = new SimpleStringProperty(direccion);
        this.itelefono = new SimpleIntegerProperty(telefono);
    }

	public StringProperty sNombreProperty() {
		return this.sNombre;
	}
	
	public String getSNombre() {
		return this.sNombre.get();
	}
	
	public void setSNombre(String sNombre) {
		this.sNombre.set(sNombre);
	}

	public StringProperty sApellidosProperty() {
		return this.sApellidos;
	}

	public String getSApellidos() {
		return this.sApellidos.get();
	}
	
	public void setSApellidos(String sApellidos) {
		this.sApellidos.set(sApellidos);
	}
	
	public StringProperty sDniProperty() {
		return this.sDni;
	}

	public String getSDni() {
		return this.sDni.get();
	}

	public void setSDni(String sDni) {
		this.sDni.set(sDni);
	}

	public StringProperty sPolizaProperty() {
		return this.sPoliza;
	}

	public String getSPoliza() {
		return this.sPoliza.get();
	}
	
	public void setSPoliza(String sPoliza) {
		this.sPoliza.set(sPoliza);
	}
	public StringProperty sPrimaProperty() {
		return this.sPrima;
	}

	public String getSPrima() {
		return this.sPrima.get();
	}
	
	public void setSPrima(String sPrima) {
		this.sPrima.set(sPrima);
	}
	
	public StringProperty sCoberturaProperty() {
		return this.sCobertura;
	}
	
	public String getSCobertura() {
		return this.sCobertura.get();
	}
	
	public void setSCobertura(String sCobertura) {
		this.sCobertura.set(sCobertura);
	}
	
	public StringProperty sCorreoProperty() {
		return this.sCorreo;
	}
	
	public String getSCorreo() {
		return this.sCorreo.get();
	}
	
	public void setSCorreo(String sCorreo) {
		this.sCorreo.set(sCorreo);
	}
	
	public ObjectProperty<LocalDate> sfechanacProperty() {
		return this.sfechanac;
	}
	
	public LocalDate getSfechanac() {
		return this.sfechanac.get();
	}
	
	public void setSfechanac(LocalDate sfechanac) {
		this.sfechanac.set(sfechanac);
	}

	public IntegerProperty icPostalProperty() {
		return this.icPostal;
	}
	
	public int getIcPostal() {
		return this.icPostal.get();
	}
	
	public void setIcPostal(int icPostal) {
		this.icPostal.set(icPostal);
	}

	public StringProperty sdireccionProperty() {
		return this.sdireccion;
	}

	public String getSdireccion() {
		return this.sdireccion.get();
	}
	
	public void setSdireccion(String sdireccion) {
		this.sdireccion.set(sdireccion);
	}
	
	public IntegerProperty itelefonoProperty() {
		return this.itelefono;
	}

	public int getItelefono() {
		return this.itelefono.get();
	}
	
	public void setItelefono(int itelefono) {
		this.itelefono.set(itelefono);
	}
}
