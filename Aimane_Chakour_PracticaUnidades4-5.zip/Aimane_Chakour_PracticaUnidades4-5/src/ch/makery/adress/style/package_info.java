/**
 * Contiene el las hojas de estilo CSS de la aplicaci�n
 */
package ch.makery.adress.style;
