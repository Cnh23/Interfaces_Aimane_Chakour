package ch.makery.adress;
	
import ch.makery.adress.view.MenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

/**
 * Clase principal que ejecuta la aplicaci�n JavaFX.
 *
 * @author Aimane Chakour
 * @version 1.0
 */

public class Main extends Application {
	/**
	 * Contenedor principal que almacena los elementos de la interfaz gr�fica de usuario.
	 */
	private BorderPane rootLayout;
	
	/**
	 * M�todo que se ejecuta cuando se inicia la aplicaci�n.
	 * 
	 * @param primaryStage Escenario principal donde se mostrar� la interfaz gr�fica de usuario.
	 */
	@Override
	public void start(Stage primaryStage) {
		try {
			// Carga el dise�o del archivo FXML en la variable rootLayout
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/Inicio.fxml"));
			rootLayout = (BorderPane) loader.load();
			
			// Pasamos al controlador de menu el objeto con el BorderPane principal
			MenuController menuController = loader.getController();
			menuController.setRootLayout(rootLayout);
			
			// Mostramos la escena del BorderPane de la variable rootLayot
			Scene scene = new Scene(rootLayout);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * M�todo principal que se ejecuta al iniciar la aplicaci�n.
	 * 
	 * @param args Argumentos enviados al programa.
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
