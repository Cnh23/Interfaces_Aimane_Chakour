/**
 * Contiene el Main de la aplicaci�n
 */
package ch.makery.adress;
